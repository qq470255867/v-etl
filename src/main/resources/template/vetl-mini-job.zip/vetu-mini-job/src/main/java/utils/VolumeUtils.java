package utils;

/**
 * @program: vetl-mini-job
 * @description:
 * @author: kangyu
 * @create: 2020-01-21 15:00
 **/
public class VolumeUtils {



    //匹配平台系统配置
    private static String KEY="dataVolume:";


    public static void markVolume(int volume){
        System.out.println(KEY+volume);
    }

}
