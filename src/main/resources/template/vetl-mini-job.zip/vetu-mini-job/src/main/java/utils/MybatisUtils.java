package utils;

import com.baomidou.mybatisplus.core.MybatisSqlSessionFactoryBuilder;
import mapper.BaseEntityMapper;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.Reader;

/**
 * @program: vetu_job_policelist
 * @description: mybatis 获取 SqlSession
 * @author: kangyu
 * @create: 2019-12-24 16:20
 **/
public class MybatisUtils {


    public static <T> T getMapper(String path,Class<T> clazz){
        Reader reader = null;
        try {
            reader = Resources.getResourceAsReader(path);
        } catch (IOException e) {
            e.printStackTrace();
        }
        SqlSessionFactory sessionFactory = new MybatisSqlSessionFactoryBuilder().build(reader);
        SqlSession session= sessionFactory.openSession();
        return session.getMapper(clazz);

    }

    public static SqlSession getSqlSession(String path){
        Reader reader = null;
        try {
            reader = Resources.getResourceAsReader(path);
        } catch (IOException e) {
            e.printStackTrace();
        }
        SqlSessionFactory sessionFactory = new MybatisSqlSessionFactoryBuilder().build(reader);
        return sessionFactory.openSession();
    }


}
