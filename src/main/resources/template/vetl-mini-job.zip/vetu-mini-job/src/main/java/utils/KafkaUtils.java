package utils;

import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @program: reclist-push-access
 * @description: kafka 获取生产者和消费者工具类
 * @author: kangyu
 * @create: 2019-12-30 15:17
 **/
public class KafkaUtils {

    private static KafkaProducer<String, String> kafkaProducer;

    private static KafkaConsumer<String, String> kafkaConsumer;

    static {
        try {
            InputStream is= KafkaUtils.class.getResourceAsStream("/kafka-producer.properties");
            Properties producerProperties=new Properties();
            producerProperties.load(is);
            kafkaProducer = new KafkaProducer<String, String>(producerProperties);
            InputStream ism= KafkaUtils.class.getResourceAsStream("/kafka-consumer.properties");
            Properties consumerProperties=new Properties();
            producerProperties.load(ism);
            kafkaConsumer = new KafkaConsumer<String, String>(consumerProperties);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized static KafkaProducer getKafkaProducer(){

        try
        {
            if (kafkaProducer!=null)
            {
                return kafkaProducer;
            }else {
                return null;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    public synchronized static KafkaConsumer getKafkaConsumer(){

        try
        {
            if (kafkaConsumer!=null)
            {
                return kafkaConsumer;
            }else {
                return null;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }




}
