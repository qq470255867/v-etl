package config;

import com.alibaba.druid.pool.DruidDataSource;
import org.apache.ibatis.datasource.pooled.PooledDataSourceFactory;

/**
 * @program: vetu-mini-job
 * @description: druid连接池，用于配置 mysql-mybatis.config.xml、oracle-mybatis-config.xml
 * @author: kangyu
 * @create: 2019-12-30 17:11
 **/

public class DruidDataSourceFactory extends PooledDataSourceFactory {

    public DruidDataSourceFactory() {

        this.dataSource = new DruidDataSource();
    }
}
