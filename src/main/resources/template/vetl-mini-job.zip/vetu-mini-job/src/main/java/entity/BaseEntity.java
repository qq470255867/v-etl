package entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * @program: vetu_job_policelist
 * @description: 实体类
 * @author: kangyu
 * @create: 2019-12-24 16:13
 **/
@Data
@TableName("")
public class BaseEntity {


}
