import com.alibaba.fastjson.JSON;
import entity.BaseEntity;
import mapper.BaseEntityMapper;
import mapper.WriteMapper;
import org.apache.ibatis.session.SqlSession;
import redis.clients.jedis.Jedis;
import sun.rmi.runtime.Log;
import utils.*;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.log4j.Logger;

import java.util.List;


/**
 * @program: vetu_job_policelist
 * @description:  运行主类
 * @author: kangyu
 * @create: 2019-12-20 19:37
 **/
public class JobMain {

    public static void main(String[] args) throws Exception {

        //日志操作
        final Logger log = Logger.getLogger(JobMain.class);

        try {
            log.info("jobMain start");

            //oracle操作
            BaseEntityMapper baseEntityMapper = MybatisUtils.
                    getMapper("oracle-mybatis-config.xml", BaseEntityMapper.class);

            BaseEntity entity = baseEntityMapper.selectById("1");

            List<BaseEntity> baseEntities = baseEntityMapper.selectList(null);

            //平台统计接入量
            VolumeUtils.markVolume(baseEntities.size());


            String entityJsonStr = JSON.toJSONString(entity);
            //redis操作
            Jedis jedis = RedisUtils.getJedis();

            jedis.set("demoKey", entityJsonStr);
            //kafka操作
            KafkaProducer kafkaProducer = KafkaUtils.getKafkaProducer();

            ProducerRecord<String, String> record = new ProducerRecord<>("mytopic", entityJsonStr);

            kafkaProducer.send(record);

            kafkaProducer.close();
            //mysql 操作
            SqlSession sqlSession = MybatisUtils.getSqlSession("mysql-mybatis.config.xml");

            WriteMapper writeMapper = sqlSession.getMapper(WriteMapper.class);

            writeMapper.insert(entity);

            sqlSession.commit();

            sqlSession.close();
            //ftp 操作
            FTPUtils ftpUtils = FTPUtils.getInstance();

            ftpUtils.downloadFile("/home/","test.json","D:\\");

            //SFTP 操作
            SFTPUtils.downloadFile("/home/","test.json","D:\\");



        }catch (Exception e){
            log.error(e.getMessage(),e);
        }
    }


}
