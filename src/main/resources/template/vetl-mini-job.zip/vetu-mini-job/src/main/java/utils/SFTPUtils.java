package utils;

import com.jcraft.jsch.*;
import org.apache.commons.net.ftp.FTPClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

public class SFTPUtils {
    
    /** 日志记录器  */
    private static Logger logger =  LoggerFactory.getLogger(SFTPUtils.class);
    /** Session */
    private static Session session = null;
    /** Channel */
    private static ChannelSftp channel = null;
    /** SFTP服务器IP地址 */
    private static String host;
    /** SFTP服务器端口 */
    private static int port;
    /** 连接超时时间，单位毫秒  */
    private static int timeout;
    
    /** 私钥 */    
    private static String privateKey;
    
    /** 用户名 */
    private static String username;
    /** 密码 */
    private static String password;

    private static List<String> lsFTPFiles;


    static {
        try {
            InputStream resourceAsStream = FTPUtils.class.getResourceAsStream("/ftpConfig.properties");
            Properties properties=new Properties();
            properties.load(resourceAsStream);
            host = (String) properties.get("sftp.hostname");
            port =  Integer.parseInt((String)properties.get("sftp.port"));
            username = (String) properties.get("sftp.username");
            password = (String) properties.get("sftp.password");
            timeout = Integer.parseInt((String)properties.get("sftp.password"));
            privateKey = (String) properties.get("sftp.password");
            login();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 登陆SFTP服务器
     * @return boolean
     */
    public static boolean login() {
        
        try {
            JSch jsch = new JSch();
            session = jsch.getSession(username, host, port);
            if (privateKey != null) {  
                jsch.addIdentity(privateKey);// 设置私钥  
            }
            if(password != null){
                session.setPassword(password);
            }
            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no"); 
            config.put("PreferredAuthentications","publickey,keyboard-interactive,password"); // 不加这行会报错 Kerberos username [xxxxxx]: 
            session.setConfig(config);
            session.setTimeout(timeout);
            session.connect();
            logger.debug("sftp session connected");
            
            logger.debug("opening channel");
            channel = (ChannelSftp)session.openChannel("sftp");
            channel.connect();
            
            logger.debug("connected successfully");

            return true;
        } catch (JSchException e) {
            logger.error("sftp login failed:"+e.getMessage());
            return false;
        }
    }
    
    /**
     * 上传文件
     * @param pathName SFTP服务器目录
     * @param fileName 服务器上保存的文件名
     * @param input 输入文件流
     * @return boolean
     */
    public static boolean uploadFile(String filePath, String fileName, InputStream input, String isSkip){
    	
    	try {
			if(!isDirExist(filePath)){ //不存在则创建
				makeDir(filePath);
			}
		} catch (SftpException e1) {
			e1.printStackTrace();
		}
    	
        //String currentDir = currentDir();
        if(!changeDir(filePath)){
            return false;
        }
        
        try {
        	if( ifExits( filePath+"/"+fileName ) && "1".equals(isSkip) ){ // 跳过文件
        		logger.info("Skipped.File exits:"+filePath+"/"+fileName);
        		return true;
        	}
        	if( ifExits( filePath+"/"+fileName ) && "3".equals(isSkip) ){ // 自动 备份/重命名：原文件名+“.bak20181016111630222”
        		channel.rename(filePath+"/"+fileName, filePath+"/"+fileName+".bak");
        	}
            channel.put(input,fileName,ChannelSftp.OVERWRITE);
            if(!existFile(fileName)){
                logger.debug("upload failed");
                return false;
            }
            logger.debug("upload successful");
            return true;
        } catch (SftpException e) {
            logger.error("upload failed",e);
            return false;
        } finally {
            changeDir("/");
        }
    }
    
    /**
     * 上传文件
     * @param pathName SFTP服务器目录
     * @param fileName 服务器上保存的文件名
     * @param localFile 本地文件
     * @return boolean
     */
    public static  boolean uploadFile(String filePath,String fileName,String localFile,String isSkip){
       
    	try {
			if(!isDirExist(filePath)){ //不存在则创建
				makeDir(filePath);
			}
		} catch (SftpException e1) {
			e1.printStackTrace();
		}
    	
        if(!changeDir(filePath)){
            return false;
        }
    	
        try {
        	if( ifExits( filePath+"/"+fileName ) && "1".equals(isSkip) ){ // 跳过文件
        		logger.info("Skipped.File exits:"+filePath+"/"+fileName);
        		return true;
        	}
        	if( ifExits( filePath+"/"+fileName ) && "3".equals(isSkip) ){ // 自动 备份/重命名：原文件名+“.bak20181016111630222”
        		channel.rename( fileName,  fileName+".bak");
        	}
            channel.put(localFile,  fileName ,ChannelSftp.OVERWRITE);
            if(!existFile(fileName)){
                logger.debug("upload failed");
                return false;
            }
            logger.debug("upload successful");
            return true;
        } catch (SftpException e) {
            logger.error("upload failed",e);
            return false;
        } finally {
        	 changeDir("/");
        }
    }
    
    /**
     * 下载文件
     * <p>
     * 使用示例，SFTP服务器上的目录结构如下：/testA/testA_B/
     * <table border="1">
     * <tr><td>当前目录</td><td>方法</td><td>参数：绝对路径/相对路径</td><td>下载后</td></tr>
     * <tr><td>/</td><td>downloadFile("testA","down.txt","D:\\downDir")</td><td>相对路径</td><td>D:\\downDir\\down.txt</td></tr>
     * <tr><td>/</td><td>downloadFile("testA/testA_B","down.txt","D:\\downDir")</td><td>相对路径</td><td>D:\\downDir\\down.txt</td></tr>
     * <tr><td>/</td><td>downloadFile("/testA/testA_B","down.txt","D:\\downDir")</td><td>绝对路径</td><td>D:\\downDir\\down.txt</td></tr>
     * </table>
     * </p>
     * @param remotePath SFTP服务器目录
     * @param fileName 服务器上需要下载的文件名
     * @param localPath 本地保存绝对路径
     * @return boolean
     */
    public static  boolean downloadFile(String remotePath,String fileName,String localPath){
        
        String currentDir = currentDir();
        if(!changeDir(remotePath)){
            return false;
        }
        
        try {
            channel.get(fileName,localPath);
            
            File localFile = new File(localPath);
            if(!localFile.exists()){
                logger.debug("download file failed");
                return false;
            }
            logger.debug("download successful");
            return true;
        } catch (SftpException e) {
            logger.error("download file failed",e);
            return false;
        } finally {
            changeDir(currentDir);
        }
    }
    
    /**
     * 下载文件
     * @param remotePath 文件的SFTP绝对路径
     * @param localPath 保存文件的本地绝对路径
     * @return
     */
    public static boolean downloadFile2(String remotePath, String localPath){
        try {
        	//changeToHomeDir();
            channel.get( remotePath,localPath);          
        } catch (SftpException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }
    
    /**
     * 切换工作目录
     * <p>
     * @param pathName 路径
     * @return boolean
     */
    public static boolean changeDir(String pathName){
        if(pathName == null || pathName.trim().equals("")){
            logger.debug("invalid pathName");
            return false;
        }
        
        try {
            channel.cd(pathName.replaceAll("\\\\", "/"));
            logger.debug("directory successfully changed,current dir=" + channel.pwd());
            return true;
        } catch (SftpException e) {
            logger.error("failed to change directory",e);
            return false;
        }
    }
    
    /**
     * 切换到上一级目录
     * <p>
     * 使用示例，SFTP服务器上的目录结构如下：/testA/testA_B/
     * <table border="1">
     * <tr><td>当前目录</td><td>方法</td><td>切换后的目录</td></tr>
     * <tr><td>/testA/</td><td>changeToParentDir()</td><td>/</td></tr>
     * <tr><td>/testA/testA_B/</td><td>changeToParentDir()</td><td>/testA/</td></tr>
     * </table>
     * </p>
     * @return boolean
     */
    public static boolean changeToParentDir(){
        return changeDir("..");
    }
    
    /**
     * 切换到根目录
     * @return boolean
     */
    public static boolean changeToHomeDir(){
        String homeDir = null;
        try {
            homeDir = channel.getHome();
        } catch (SftpException e) {
            logger.error("can not get home directory",e);
            return false;
        }
        return changeDir(homeDir);
    }
    
    /**
     * 创建目录
     * <p>
     * 使用示例，SFTP服务器上的目录结构如下：/testA/testA_B/
     * <table border="1">
     * <tr><td>当前目录</td><td>方法</td><td>参数(绝对路径/相对路径)</td><td>创建成功后的目录</td></tr>
     * <tr><td>/testA/testA_B/</td><td>makeDir("testA_B_C")</td><td>相对路径</td><td>/testA/testA_B/testA_B_C/</td></tr>
     * <tr><td>/</td><td>makeDir("/testA/testA_B/testA_B_D")</td><td>绝对路径</td><td>/testA/testA_B/testA_B_D/</td></tr>
     * </table>
     * <br/>
     * <b>注意</b>，当<b>中间目录不存在</b>的情况下，不能够使用绝对路径的方式期望创建中间目录及目标目录。
     * 例如makeDir("/testNOEXIST1/testNOEXIST2/testNOEXIST3")，这是错误的。
     * </p>
     * @param dirName 目录
     * @return boolean
     */
    public static boolean makeDir(String dirName){
        try {
 //           channel.mkdir(dirName);
            String[] folders = dirName.split( "/" );  
            for ( String folder : folders ) {  
                if ( folder.length() > 0 ) {  
                    try {  
                    	channel.cd( folder );  
                    }  
                    catch ( SftpException e ) {  
                    	channel.mkdir( folder );  
                    	channel.cd( folder );  
                    }  
                }  
            }
            logger.debug("directory successfully created,dir=" + dirName);
            return true;
        } catch (SftpException e) {
            logger.error("failed to create directory", e);
            return false;
        }
    }
    
    
    
    
    /**
     * 删除文件夹
     * @param dirName
     * @return boolean
     */
    @SuppressWarnings("unchecked")
    public static boolean delDir(String dirName){
        if(!changeDir(dirName)){
            return false;
        }
        
        Vector<ChannelSftp.LsEntry> list = null;
        try {
            list = channel.ls(channel.pwd());
        } catch (SftpException e) {
            logger.error("can not list directory",e);
            return false;
        }
        
        for(ChannelSftp.LsEntry entry : list){
            String fileName = entry.getFilename();
            if(!fileName.equals(".") && !fileName.equals("..")){
                if(entry.getAttrs().isDir()){
                    delDir(fileName);
                } else {
                    delFile(fileName);
                }
            }
        }
        
        if(!changeToParentDir()){
            return false;
        }
        
        try {
            channel.rmdir(dirName);
            logger.debug("directory " + dirName + " successfully deleted");
            return true;
        } catch (SftpException e) {
            logger.error("failed to delete directory " + dirName,e);
            return false;
        }
    }
    
    /**
     * 删除文件
     * @param fileName 文件名
     * @return boolean
     */
    public static boolean delFile(String fileName){
        if(fileName == null || fileName.trim().equals("")){
            logger.debug("invalid filename");
            return false;
        }
        
        try {
            channel.rm(fileName);
            logger.debug("file " + fileName + " successfully deleted");
            return true;
        } catch (SftpException e) {
            logger.error("failed to delete file " + fileName,e);
            return false;
        }
    }
    
    /**
     * 当前目录下文件及文件夹名称列表
     * @return String[]
     */
    public static String[] ls(){
        return list(Filter.ALL);
    }
    
    /**
     * 指定目录下文件及文件夹名称列表
     * @return String[]
     */
    public static String[] ls(String pathName){
        String currentDir = currentDir();
        if(!changeDir(pathName)){
            return new String[0];
        };
        String[] result = list(Filter.ALL);
        if(!changeDir(currentDir)){
            return new String[0];
        }
        return result;
    }
    
    /**
     * 当前目录下文件名称列表
     * @return String[]
     */
    public static String[] lsFiles(){
        return list(Filter.FILE);
    }
    
    /**
     * 指定目录下文件名称列表
     * @return String[]
     */
    public static String[] lsFiles(String pathName){
        String currentDir = currentDir();
        if(!changeDir(pathName)){
            return new String[0];
        };
        String[] result = list(Filter.FILE);
        if(!changeDir(currentDir)){
            return new String[0];
        }
        return result;
    }
    
    /**
     * 当前目录下文件夹名称列表
     * @return String[]
     */
    public static String[] lsDirs(){
        return list(Filter.DIR);
    }
    
    /**
     * 指定目录下文件夹名称列表
     * @return String[]
     */
    public static String[] lsDirs(String pathName){
        String currentDir = currentDir();
        if(!changeDir(pathName)){
            return new String[0];
        };
        String[] result = list(Filter.DIR);
        if(!changeDir(currentDir)){
            return new String[0];
        }
        return result;
    }
    
    /**
     * 当前目录是否存在文件或文件夹
     * @param name 名称
     * @return boolean
     */
    public static boolean exist(String name){
        return exist(ls(), name);
    }
    
    /**
     * 指定目录下，是否存在文件或文件夹
     * @param path 目录
     * @param name 名称
     * @return boolean
     */
    public static boolean exist(String path,String name){
        return exist(ls(path),name);
    }
    
    /**
     * 当前目录是否存在文件
     * @param name 文件名
     * @return boolean
     */
    public static boolean existFile(String name){
        return exist(lsFiles(),name);
    }
    
    /**
     * 指定目录下，是否存在文件
     * @param path 目录
     * @param name 文件名
     * @return boolean
     */
    public static boolean existFile(String path,String name){
        return exist(lsFiles(path), name);
    }
    
    /**
     * 当前目录是否存在文件夹
     * @param name 文件夹名称
     * @return boolean
     */
    public static boolean existDir(String name){
        return exist(lsDirs(), name);
    }
    
    /**
     * 指定目录下，是否存在文件夹
     * @param path 目录
     * @param name 文家夹名称
     * @return boolean
     */
    public static boolean existDir(String path,String name){
        return exist(lsDirs(path), name);
    }
    
    /**
     * 当前工作目录
     * @return String
     */
    public static String currentDir(){
        try {
            return channel.pwd();
        } catch (SftpException e) {
            logger.error("failed to get current dir",e);
            return homeDir();
        }
    }
    
    /**
     * 登出
     */
    public static void logout(){
        if(channel != null){
            channel.quit();
            channel.disconnect();
        }
        if(session != null){
            session.disconnect();
        }
        logger.debug("logout successfully");
    }
    
    
    //------private method ------
    
    /** 枚举，用于过滤文件和文件夹  */
    private enum Filter {/** 文件及文件夹 */ ALL ,/** 文件 */ FILE ,/** 文件夹 */ DIR };
    
    /**
     * 列出当前目录下的文件及文件夹
     * @param filter 过滤参数
     * @return String[] 
     */
    @SuppressWarnings("unchecked")
    private static String[] list(Filter filter){
        Vector<ChannelSftp.LsEntry> list = null;
        try {
            //ls方法会返回两个特殊的目录，当前目录(.)和父目录(..)
            list = channel.ls(channel.pwd());
        } catch (SftpException e) {
            logger.error("can not list directory",e);
            return new String[0];
        }
        
        List<String> resultList = new ArrayList<String>();
        for(ChannelSftp.LsEntry entry : list){
                resultList.add(entry.getFilename());
        }
        return resultList.toArray(new String[0]);
    }
    

    /**
     * 根目录
     * @return String
     */
    private static String homeDir(){
        try {        	
            return channel.getHome();
        } catch (SftpException e) {
            return "/";
        }
    }
    
    /**
     * 判断字符串是否存在于数组中
     * @param strArr 字符串数组
     * @param str 字符串
     * @return boolean
     */
    private static boolean exist(String[] strArr,String str){
        if(strArr == null || strArr.length == 0){
            return false;
        }
        if(str == null || str.trim().equals("")){
            return false;
        }
        for(String s : strArr){
            if(s.equalsIgnoreCase(str)){
                return true;
            }
        }
        return false;
    }
 
    /**
     * 判断 FTP 文件是否存在
     * @param absolutePath FTP绝对路径
     * @return
     */
    public static boolean ifExits(String absolutePath){
    	return getFileProperties(absolutePath)==null?false:true;
    }
    
    /**
     * 判断是否是目录
     * @param absolutePath
     * @return
     */
    public static boolean isDirectory(String absolutePath){
    	SftpATTRS sss = getFileProperties(absolutePath);
    	if( null!=sss ){
    		return sss.isDir();
    	}
    	return false;
    }
    
    /**
     * 获取FTP服务器上的文件属性：修改时间，文件大小，创建时间，文件权限 等等
     * @param ftpFilePath
     * @return
     */
    public static SftpATTRS getFileProperties(String ftpFilePath ){
    	SftpATTRS ss=null;
		try {
			ss = channel.stat( ftpFilePath );
			logger.debug("File Path:"+ ftpFilePath );
	        logger.debug("File modify time:" ); // ss.getMtimeString()
	        logger.debug("File size:"+ ss.getSize()+"bytes");
		} catch (SftpException e) {
			//logger.error("Failed to get file properties:"+ e.getMessage());
		}
    	return ss;
    }
    
    /**
	 * inputStream类型转换为byte类型
	 * @param iStrm
	 * @return
	 * @throws IOException
	 */
	public static byte[] inputStreamToByte (InputStream iStrm) throws IOException {
		ByteArrayOutputStream bytestream = new ByteArrayOutputStream();
		int ch;
		while ((ch = iStrm.read()) != -1) {
			bytestream.write(ch);
		}
		byte imgdata[] = bytestream.toByteArray();
		bytestream.close();
		return imgdata;
	}
 
    
    /**
	 * 获取远程文件的流文件
	 * @param sftpFilePath
	 * @return
	 * @throws SftpException
	 */
	public static InputStream getFile (String sftpFilePath) throws SftpException {
		//if (isFileExist(sftpFilePath)) {
			return channel.get(sftpFilePath);
		//}
		//return null;
	}
 
    
    /** 
	 * 获取远程文件字节流
	 * @param sftpFilePath
	 * @return
	 * @throws SftpException
	 * @throws IOException
	 */
	public static ByteArrayInputStream getByteArrayInputStreamFile (String sftpFilePath) throws SftpException,IOException {
		//if (isFileExist(sftpFilePath)) {
			byte[] srcFtpFileByte = inputStreamToByte(getFile(sftpFilePath));
			ByteArrayInputStream srcFtpFileStreams = new ByteArrayInputStream(srcFtpFileByte);
			return srcFtpFileStreams;
		//}
		//return null;
	}
    
    /**
	 * 移动远程文件到目标目录
	 * @param srcSftpFilePath
	 * @param distSftpFilePath
	 * @return 返回移动成功或者失败代码和信息
	 * @throws SftpException
	 * @throws IOException
	 */
	public static String moveFile (String srcSftpFilePath, String distSftpFilePath) throws SftpException,IOException {
		String retInfo = "";
		boolean dirExist = false;
		//boolean result = false;
		if (!(dirExist)) {
			//1建立目录
			makeDir(distSftpFilePath);
			//2设置dirExist为true
			dirExist = true;
		}
		if (dirExist) {
 
			String fileName = srcSftpFilePath.substring(srcSftpFilePath.lastIndexOf("/"), srcSftpFilePath.length());
			ByteArrayInputStream srcFtpFileStreams = getByteArrayInputStreamFile(srcSftpFilePath);
			//二进制流写文件
			channel.put(srcFtpFileStreams, distSftpFilePath + fileName);
			channel.rm(srcSftpFilePath);
			retInfo = "1:move success!";
		}
		return retInfo;
	}
	
	/**
	 * 判断目录是否存在
	 * @param directory
	 * @return
	 * @throws SftpException
	 */
	public static boolean isDirExist (String directory) throws SftpException {
		boolean isDirExistFlag = false;
		try {
			SftpATTRS sftpATTRS = channel.lstat(directory);
			isDirExistFlag = true;
			return sftpATTRS.isDir();
		} catch (Exception e) {
			if (e.getMessage().toLowerCase().equals("no such file")) {
				isDirExistFlag = false;
			}
		}
		return isDirExistFlag;
	}
 
 
	/**
	 * 递归：列出指定目录下的所有子目录和文件（不包含空目录）
	 * @param ftpPath SFTP上的绝对路径，比如 “/TEST/Cloudy”
	 * @return lsFiles 返回所有文件的绝对路径
	 */
	@SuppressWarnings("unchecked")	
	public static void listFTPFilesByPath(String ftpPath){
    	try {
    		channel.cd(ftpPath);    		
    		Vector<ChannelSftp.LsEntry> v = channel.ls("*");// 列出服务器指定的文件列表
            for(ChannelSftp.LsEntry entry : v){
                String fileName = entry.getFilename();
                String currentPath = ftpPath+"/"+fileName;
                if(!fileName.equals(".") && !fileName.equals("..")){
                    if(entry.getAttrs().isDir()){
                    	getListFilesByPath( currentPath );
                    } else {
                    	lsFTPFiles.add(currentPath);
                    	//logger.info( currentPath );
                    }
                }
            }
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
	
	/**
	 * 递归：列出指定目录下的所有子目录和文件（不包含空目录）
	 * @param ftpPath SFTP上的绝对路径，比如 “/TEST/Cloudy”
	 * @return lsFiles 返回所有文件的绝对路径
	 */
	public static List<String> getListFilesByPath(String ftpPath){
		listFTPFilesByPath(ftpPath);
    	return removeDuplicateString(lsFTPFiles);// 去重（防止全局变量重用时 重复设值）
    }
	
	/**
	 * 递归：列出指定目录下的所有子目录和文件（不包含空目录）
	 * @param ftpPath SFTP上的绝对路径，比如 “/TEST/Cloudy”
	 * @return fileNames 返回所有文件的相对于传入路径的文件名
	 */
	public static String[] getListFilesNameByPath(String ftpPath){
		String[]  fileNames = null;
		List<String> lsFiles = getListFilesByPath( ftpPath );
		if( null!=lsFiles && lsFiles.size()>0 ){
			fileNames = new String[lsFiles.size()];
			for( int x=0;x<lsFiles.size();x++ ){
				fileNames[x] = ( new File( lsFiles.get(x) ) ).getName();				
			}			
		}		
		return fileNames;
	}
    
    /**
     * 去重：String
     * @param list
     * @return
     */
	public static List<String> removeDuplicateString(List<String> list) {
    	List<String> list_new = new ArrayList<String>();
    	for( int a=0;a<list.size();a++ ){
    		String s1 = list.get(a);
    		if( null!=list_new && list_new.size()>0 ){
	    		for(  int b=0;b<list_new.size();b++  ){
	    			if( s1.equals( list_new.get(b) ) ){
	    				break;// 重复，去掉
	    			}else{
	    				if( b+1==list_new.size() ){
	    					list_new.add( list.get(a) );
	    				}
	    			}
	    		}
    		}else{
    			list_new.add( list.get(a) );
    		}
    	}
		return list_new;
	}
	

    
    
 
    
    
}