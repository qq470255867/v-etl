package mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import entity.BaseEntity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @program: vetu-mini-job
 * @description:
 * @author: kangyu
 * @create: 2019-12-24 17:11
 **/
public interface WriteMapper extends BaseMapper<BaseEntity> {

    void batchInsert(@Param("lists") List<BaseEntity> lists);

}
