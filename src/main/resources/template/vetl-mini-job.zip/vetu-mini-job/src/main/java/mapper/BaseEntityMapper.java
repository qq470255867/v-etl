package mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import entity.BaseEntity;

import java.util.List;

public interface BaseEntityMapper extends BaseMapper<BaseEntity> {

    List<BaseEntity> getBaseEntities();

}
